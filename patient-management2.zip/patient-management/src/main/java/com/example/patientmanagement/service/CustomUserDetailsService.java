package com.example.patientmanagement.service;

import com.example.patientmanagement.entity.Patient;
import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.repository.PatientRepository;
import com.example.patientmanagement.repository.PhysicianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private PhysicianRepository physicianRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Try loading the patient first
        Patient patient = patientRepository.findByEmail(username);
        if (patient != null) {
            return new org.springframework.security.core.userdetails.User(patient.getEmail(),
                    patient.getPassword(), getAuthorities(patient));
        }

        // If patient not found, try loading the physician
        Physician physician = physicianRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        return new org.springframework.security.core.userdetails.User(physician.getEmail(),
                "", getAuthorities(physician));  // Empty password for physician (you can adjust this if needed)
    }

    private Collection<? extends GrantedAuthority> getAuthorities(Patient patient) {
        return Arrays.asList(new SimpleGrantedAuthority("ROLE_PATIENT"));
    }

    private Collection<? extends GrantedAuthority> getAuthorities(Physician physician) {
        Set<GrantedAuthority> authorities = new HashSet<>();
        for (String role : physician.getRoles()) {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + role));
        }
        return authorities;
    }
}


