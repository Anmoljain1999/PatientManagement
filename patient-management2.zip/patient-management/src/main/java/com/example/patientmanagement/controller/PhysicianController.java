package com.example.patientmanagement.controller;

import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.service.PhysicianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PhysicianController {

    @Autowired
    private PhysicianService physicianService;

//    @GetMapping("/physicians")
//    public String listPhysicians(Model model) {
//        model.addAttribute("physicians", physicianService.findAll());
//        return "physician-list"; // A view to list all physicians
//    }

    @GetMapping("/add-physician")
    public String showAddPhysicianForm(Model model) {
        model.addAttribute("physician", new Physician());
        return "add-physician"; // A view to add a new physician
    }

    @PostMapping("/add-physician")
    public String addPhysician(Physician physician) {
        physicianService.savePhysician(physician);
        return "redirect:/physicians"; // Redirect to the list of physicians
    }

    // Other methods for editing and deleting physicians can be added here
}