package com.example.patientmanagement.repository;

import com.example.patientmanagement.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    boolean existsByPhysicianIdAndPatientIdAndIsConfirmed(Long physicianId, Long patientId, boolean isConfirmed);

    Appointment findByPatientId(Long patientId);
}