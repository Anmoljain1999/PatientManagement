package com.example.patientmanagement.service;

import com.example.patientmanagement.entity.Appointment;
import com.example.patientmanagement.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AppointmentService {
    @Autowired
    private EmailService emailService;
    @Autowired
    private AppointmentRepository appointmentRepository;

    public boolean isPhysicianAvailable(Long physicianId, LocalDateTime appointmentDateTime) {
        List<Appointment> appointments = appointmentRepository.findAll();
        for (Appointment appointment : appointments) {
            if (appointment.getPhysician().getId().equals(physicianId) &&
                    appointment.getAppointmentDateTime().isEqual(appointmentDateTime)) {
                return false; // Physician is not available
            }
        }
        return true; // Physician is available
    }


    public void bookAppointment(Appointment appointment) {
        appointment.setConfirmed(false); // Set to false until confirmation
        appointmentRepository.save(appointment);
        String appointmentDetails = "Appointment with Dr. " + appointment.getPhysician().getFullName() +
                " on " + appointment.getAppointmentDateTime();
        emailService.sendConfirmationEmail(appointment.getPatient().getEmail(), appointmentDetails); // Use EmailService
    }

    public Appointment findAppointmentById(Long id) {
        return appointmentRepository.findById(id).orElse(null);
    }

    public void confirmAppointment(Long id) {
        Appointment appointment = findAppointmentById(id);
        if (appointment != null) {
            appointment.setConfirmed(true);
            appointmentRepository.save(appointment);
        }
    }

    public boolean hasAppointmentWithPatient(Long physicianId, Long patientId) {
        return appointmentRepository.existsByPhysicianIdAndPatientIdAndIsConfirmed(physicianId, patientId, true);
    }

    public Long getPhysicianIdByPatientId(Long patientId) {
        Appointment appointment = appointmentRepository.findByPatientId(patientId);
        return appointment != null ? appointment.getPhysician().getId() : null;
    }
}
