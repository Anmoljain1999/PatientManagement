package com.example.patientmanagement.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime appointmentDateTime;

    private String reasonForVisit;

    @ManyToOne
    @JoinColumn(name = "patient_id")
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "physician_id")
    private Physician physician;

    private boolean isConfirmed;
    // For appointment confirmation

    public Appointment(){

    }

    // Getters and Setters
    public Appointment(Patient patient, Physician physician, LocalDateTime appointmentDateTime, String reasonForVisit) {
        this.patient = patient;
        this.physician = physician;
        this.appointmentDateTime = appointmentDateTime;
        this.reasonForVisit = reasonForVisit;
    }

}