package com.example.patientmanagement.service;

import com.example.patientmanagement.entity.Patient;
import com.example.patientmanagement.entity.VerificationToken;
import com.example.patientmanagement.exception.InvalidTokenException;
import com.example.patientmanagement.repository.PatientRepository;
import com.example.patientmanagement.repository.VerificationTokenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private EmailService emailService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private VerificationTokenRepository tokenRepository;

    public void registerPatient(Patient patient) {
        patient.setPassword(passwordEncoder.encode(patient.getPassword()));
        patient.setActive(false); // Set to false until email verification
        patient.setRoles(Set.of("ROLE_PATIENT")); // Assign default role
        patientRepository.save(patient);

        VerificationToken verificationToken = createVerificationToken(patient, 24); // 24-hour validity
        tokenRepository.save(verificationToken);

        emailService.sendVerificationEmail(patient.getEmail(), verificationToken.getToken());
    }


    public void sendPasswordResetEmail(String email) {
        Patient patient = findByEmail(email);
        if (patient != null) {
            VerificationToken resetToken = createVerificationToken(patient, 1); // 1-hour validity
            tokenRepository.save(resetToken);

            emailService.sendPasswordResetEmail(email, resetToken.getToken());
        }
    }

    public void resetPassword(String token, String newPassword) {
        VerificationToken resetToken = tokenRepository.findByToken(token)
                .orElseThrow(() -> new RuntimeException("Invalid password reset token"));

        if (resetToken.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token has expired");
        }

        Patient patient = resetToken.getPatient();
        patient.setPassword(passwordEncoder.encode(newPassword));
        patientRepository.save(patient);

        tokenRepository.delete(resetToken); // Invalidate token after use
    }
    public Patient findByEmail(String email) {
        return patientRepository.findByEmail(email);
    }

    public void verifyEmail(String token) {
        VerificationToken verificationToken = tokenRepository.findByToken(token)
                .orElseThrow(() -> new InvalidTokenException("Invalid verification token"));

        if (verificationToken.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new InvalidTokenException("Token has expired");
        }

        Patient patient = verificationToken.getPatient();
        patient.setActive(true);
        patientRepository.save(patient);

        verificationToken.setConfirmedAt(LocalDateTime.now());
        tokenRepository.save(verificationToken);
    }



    private VerificationToken createVerificationToken(Patient patient, long hoursValid) {
        VerificationToken token = new VerificationToken();
        token.setToken(UUID.randomUUID().toString());
        token.setCreatedAt(LocalDateTime.now());
        token.setExpiresAt(LocalDateTime.now().plusHours(hoursValid));
        token.setPatient(patient);
        return token;
    }

    public void updateDemographics(Long id, Patient updatedPatient) {
        Patient existingPatient = patientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patient not found with id: " + id));

        existingPatient.setPhoneNumber(updatedPatient.getPhoneNumber());
        existingPatient.setAddress(updatedPatient.getAddress());
        existingPatient.setKnownAllergies(updatedPatient.getKnownAllergies());
        existingPatient.setOngoingConditions(updatedPatient.getOngoingConditions());
        existingPatient.setEmergencyContactName(updatedPatient.getEmergencyContactName());
        existingPatient.setEmergencyContactRelationship(updatedPatient.getEmergencyContactRelationship());
        existingPatient.setEmergencyContactPhone(updatedPatient.getEmergencyContactPhone());
        existingPatient.setInsuranceProvider(updatedPatient.getInsuranceProvider());
        existingPatient.setPolicyNumber(updatedPatient.getPolicyNumber());
        existingPatient.setPolicyExpirationDate(updatedPatient.getPolicyExpirationDate());
        patientRepository.save(existingPatient);
    }

    public Patient findById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patient not found with id: " + id));
    }
}
