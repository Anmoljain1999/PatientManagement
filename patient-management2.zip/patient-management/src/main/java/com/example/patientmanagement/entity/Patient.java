package com.example.patientmanagement.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Set;


@Entity
@Data
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fullName;
    private String email;
    private String phoneNumber;
    private String gender;
    private String dateOfBirth;
    private String address; // Optional
    private String knownAllergies; // Optional
    private String ongoingConditions; // Optional
    private String password;
    private boolean active;

    // Emergency Contact Information
    private String emergencyContactName;
    private String emergencyContactRelationship;
    private String emergencyContactPhone;

    // Insurance Information
    private String insuranceProvider;
    private String policyNumber;
    private String policyExpirationDate;

    @OneToMany(mappedBy = "patient")
    private Set<Appointment> appointments;

    @ElementCollection(fetch = FetchType.EAGER)
    private Set<String> roles;

    // Getters and Setters
}