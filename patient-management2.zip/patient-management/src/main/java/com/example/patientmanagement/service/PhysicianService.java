package com.example.patientmanagement.service;

import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.repository.PhysicianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class PhysicianService {

    @Autowired
    private PhysicianRepository physicianRepository;

    public List<Physician> findAll() {
        return physicianRepository.findAll();
    }

    public void savePhysician(Physician physician) {
        physicianRepository.save(physician);
    }

    public Physician findById(Long physicianId) {
        return physicianRepository.findById(physicianId)
                .orElseThrow(() -> new RuntimeException("Physician with ID " + physicianId + " not found."));
    }

    public List<String> getAllSpecialties() {
        return physicianRepository.findDistinctSpecialties();
    }

    public List<Physician> findBySpecialtyAndLocation(String specialty, String location) {
        return physicianRepository.findBySpecialtyAndLocation(specialty, location);
    }

    public List<String> getAllLocations() {
        List<Physician> physicians = physicianRepository.findAll();
        Set<String> locations = new HashSet<>();

        for (Physician physician : physicians) {
            String location = physician.getLocation();
            if (location != null && !location.isEmpty()) {
                locations.add(location);
            }
        }

        return new ArrayList<>(locations); // Return a list of unique locations
    }


    // Other service methods for updating and deleting physicians can be added here
}