package com.example.patientmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private JavaMailSender emailSender;

    @Override
    public void sendVerificationEmail(String to, String token) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Email Verification");
        message.setText("To verify your email, click the link: " +
                "http://localhost:8080/verify?token=" + token);
        emailSender.send(message);
    }

    @Override
    public void sendConfirmationEmail(String to, String appointmentDetails) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Appointment Confirmation");
        message.setText("Your appointment is confirmed. Details: " + appointmentDetails);
        emailSender.send(message);
    }
    @Override
    public void sendPasswordResetEmail(String to, String token) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Password Reset Request");
        message.setText("To reset your password, click the link: " +
                "http://localhost:8080/reset-password?token=" + token);
        emailSender.send(message);
    }

    @Override
    public void sendConfirmationRequestEmail(String to, String appointmentDetails, Long appointmentId) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Appointment Confirmation Request");
        message.setText("You have a new appointment request:\n" +
                appointmentDetails +
                "\n\nTo confirm the appointment, click the link below:\n" +
                "http://localhost:8080/confirm-appointment?appointmentId=" + appointmentId);
        emailSender.send(message);
    }
}