package com.example.patientmanagement.service;

import com.example.patientmanagement.entity.MedicalRecord;
import com.example.patientmanagement.repository.MedicalRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MedicalRecordService {
    @Autowired
    private MedicalRecordRepository medicalRecordRepository;

    public void saveMedicalRecord(MedicalRecord medicalRecord) {
        medicalRecordRepository.save(medicalRecord);
    }

    public List<MedicalRecord> getMedicalHistory(Long patientId) {
        if (patientId == null) {
            throw new IllegalArgumentException("Patient ID cannot be null");
        }
        // Fetch medical history for the patient
        return medicalRecordRepository.findByPatientId(patientId);
    }
}
