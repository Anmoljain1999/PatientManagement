package com.example.patientmanagement.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.util.Set;

@Entity
@Data
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Full name is required")
    @Size(min = 2, max = 100, message = "Full name must be between 2 and 100 characters")
    private String fullName;

    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    @Column(unique = true, nullable = false)
    private String email;

    @NotBlank(message = "Phone number is required")
    @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits")
    private String phoneNumber;

    @NotBlank(message = "Gender is required")
    private String gender;

    @NotBlank(message = "Date of birth is required")
    private String dateOfBirth;

    @Size(max = 255, message = "Address must not exceed 255 characters")
    private String address; // Optional

    @Size(max = 255, message = "Known allergies must not exceed 255 characters")
    private String knownAllergies; // Optional

    @Size(max = 255, message = "Ongoing conditions must not exceed 255 characters")
    private String ongoingConditions; // Optional

    @NotBlank(message = "Password is required")
//    @Size(min = 8, message = "Password must be at least 8 characters long")
    private String password;

    private boolean active;

    // Emergency Contact Information
//    @NotBlank(message = "Emergency contact name is required")
    private String emergencyContactName;

//    @NotBlank(message = "Emergency contact relationship is required")
    private String emergencyContactRelationship;

//    @NotBlank(message = "Emergency contact phone is required")
    @Pattern(regexp = "^[0-9]{10}$", message = "Emergency contact phone must be 10 digits")
    private String emergencyContactPhone;

    // Insurance Information
    @Size(max = 255, message = "Insurance provider must not exceed 255 characters")
    private String insuranceProvider; // Optional

    @Size(max = 50, message = "Policy number must not exceed 50 characters")
    private String policyNumber; // Optional

    @Pattern(regexp = "\\d{4}-\\d{2}-\\d{2}", message = "Policy expiration date must be in YYYY-MM-DD format")
    private String policyExpirationDate; // Optional

    @OneToMany(mappedBy = "patient", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Appointment> appointments;

    @ElementCollection(fetch = FetchType.EAGER)
    private Set<String> roles;
}
