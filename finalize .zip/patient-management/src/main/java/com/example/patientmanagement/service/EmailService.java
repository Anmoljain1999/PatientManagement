package com.example.patientmanagement.service;

public interface EmailService {
    void sendVerificationEmail(String to, String token);
    void sendConfirmationEmail(String to, String appointmentDetails);
    void sendPasswordResetEmail(String to, String token);
    void sendConfirmationRequestEmail(String to, String appointmentDetails, Long appointmentId);
    void sendAppointmentDeclineEmail(String to, String appointmentDetails);
}