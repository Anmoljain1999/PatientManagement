package com.example.patientmanagement.entity;

import jakarta.persistence.*;
import lombok.Data;


import java.util.List;

@Entity
@Data
public class MedicalRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String diagnosisDescription;
    private String icd10Code; // Optional

    @ElementCollection
    private List<String> medications; // Drug names

    private String physicianNotes;

    @ManyToOne
    @JoinColumn(name = "patient_id")
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "physician_id")
    private Physician physician;

    // Getters and Setters
}