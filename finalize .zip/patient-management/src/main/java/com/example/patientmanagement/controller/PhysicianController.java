package com.example.patientmanagement.controller;

import com.example.patientmanagement.entity.Appointment;
import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.service.AppointmentService;
import com.example.patientmanagement.service.PhysicianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class PhysicianController {

    @Autowired
    private PhysicianService physicianService;
    @Autowired
    private AppointmentService appointmentService;


    @GetMapping("/add-physician")
    public String showAddPhysicianForm(Model model) {
        model.addAttribute("physician", new Physician());
        return "add-physician"; // A view to add a new physician
    }

    @PostMapping("/add-physician")
    public String addPhysician(Physician physician) {
        physicianService.savePhysician(physician);
        return "redirect:/physicians"; // Redirect to the list of physicians
    }

    @GetMapping("/register/physician")
    public String showPhysicianRegistrationForm(Model model) {
        model.addAttribute("physician", new Physician());
        return "physician_register"; // Thymeleaf template name
    }

    @PostMapping("/register/physician")
    public String registerPhysician(@ModelAttribute Physician physician) {
        physicianService.registerPhysician(physician);
        return "redirect:/login?registered=true";
    }


    @GetMapping("/physician/dashboard")
    public String showPhysicianDashboard(Model model) {
        // Get the currently logged-in user's email
        String email = SecurityContextHolder.getContext().getAuthentication().getName();

        // Fetch the physician using the email
        Physician physician = physicianService.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Physician not found"));

        // Fetch appointments for the physician
        List<Appointment> appointments = appointmentService.findAppointmentsByPhysicianId(physician.getId());

        // Add data to the model
        model.addAttribute("physician", physician);
        model.addAttribute("appointments", appointments);

        return "physician-dashboard"; // Render the dashboard template
    }

}