package com.example.patientmanagement.controller;

import com.example.patientmanagement.entity.Patient;
import com.example.patientmanagement.exception.DuplicateUserException;
import com.example.patientmanagement.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
public class PatientController {

    @Autowired
    private PatientService patientService;


    @GetMapping("/logout-page")
    public String logoutPage() {
        return "logout";
    }

    // Show registration form
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("patient", new Patient());
        return "registration";
    }

    @PostMapping("/register")
    public String registerPatient(@ModelAttribute Patient patient, Model model) {
        try {
            patientService.registerPatient(patient);
            model.addAttribute("patientName", patient.getFullName()); // Add patient name for a personalized message
            return "registration-success"; // Redirect to a registration success page
        } catch (DuplicateUserException e) {
            model.addAttribute("error", e.getMessage());
            return "registration"; // Stay on the registration page with error message
        } catch (Exception e) {
            model.addAttribute("error", "There was an error during registration. Please try again.");
            return "registration";
        }
    }




    @GetMapping("/verify")
    public String verifyEmail(@RequestParam("token") String token, Model model) {
        try {
            patientService.verifyEmail(token); // Call the service method to verify the email
            model.addAttribute("message", "Email verified successfully! You can now log in.");
            return "verification-success"; // Show a success page
        } catch (RuntimeException e) {
            model.addAttribute("errorMessage", "Email verification failed. Please check your token and try again.");
            return "verification-failure"; // Show a failure page
        }
    }




    // Show login form
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    // Show password recovery form
    @GetMapping("/password-recovery")
    public String showPasswordRecoveryForm() {
        return "password-recovery";
    }

    // Handle password recovery (send reset email)
    @PostMapping("/password-recovery")
    public String recoverPassword(@RequestParam String email) {
        try {
            patientService.sendPasswordResetEmail(email);
            return "redirect:/login?resetEmailSent";
        } catch (Exception e) {
            return "redirect:/password-recovery?error"; // Redirect with error message
        }
    }

    // Show reset password form
    @GetMapping("/reset-password")
    public String showResetPasswordForm(@RequestParam String token, Model model) {
        model.addAttribute("token", token);
        return "reset-password";
    }

    // Handle resetting password
    @PostMapping("/reset-password")
    public String resetPassword(@RequestParam String token, @RequestParam String newPassword) {
        try {
            patientService.resetPassword(token, newPassword);
            return "redirect:/login?passwordResetSuccess";
        } catch (Exception e) {
            return "redirect:/reset-password?error"; // Redirect to reset page with error
        }
    }


    @GetMapping("/{id}/update-demographics")
    public String showDemographicUpdateForm(@PathVariable Long id, Principal principal, Model model) {
        String email = principal.getName(); // Get logged-in user's email/username
        Patient patient = patientService.findById(id);

        if (!patient.getEmail().equals(email)) {
            throw new AccessDeniedException("Unauthorized access"); // Restrict access
        }

        model.addAttribute("patient", patient);
        return "update-demographics";
    }


    @PostMapping("/{id}/update-demographics")
    public String updateDemographics(@PathVariable Long id, @ModelAttribute Patient updatedPatient, Principal principal) {
        String email = principal.getName();
        Patient currentPatient = patientService.findById(id);

        if (!currentPatient.getEmail().equals(email)) {
            throw new AccessDeniedException("Unauthorized access");
        }

        patientService.updateDemographics(id, updatedPatient);
        return "redirect:/patients/update-success";
    }

    @GetMapping("/patients/update-success")
    public String showUpdateSuccessPage() {
        return "update-success";
    }



    @GetMapping("/dashboard")
    public String showDashboard(Principal principal, Model model) {
        // Fetch patient based on logged-in user's email/username
        String email = principal.getName(); // Assumes email is the username
        Patient patient = patientService.findByEmail(email);

        // Add patient ID to the model for demographics update
        model.addAttribute("patientId", patient.getId());
        return "dashboard"; // Thymeleaf template for dashboard
    }
}
