package com.example.patientmanagement.entity;

import jakarta.annotation.Nullable;
import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Appointment date and time is required")
    private LocalDateTime appointmentDateTime;

    @NotBlank(message = "Reason for visit is required")
    @Size(max = 255, message = "Reason for visit must not exceed 255 characters")
    private String reasonForVisit;

    @Min(value = 15, message = "Duration must be at least 15 minutes")
    @Max(value = 120, message = "Duration must not exceed 120 minutes")
    @Column(nullable = false)
    private int duration;

    @NotNull(message = "Patient information is required")
    @ManyToOne
    @JoinColumn(name = "patient_id")
    private Patient patient;

    @NotNull(message = "Physician information is required")
    @ManyToOne
    @JoinColumn(name = "physician_id")
    private Physician physician;

    private boolean isConfirmed;

    public Appointment() {
        // Default constructor
    }

    // Getters and Setters
    public Appointment(Patient patient, Physician physician, LocalDateTime appointmentDateTime, String reasonForVisit) {
        this.patient = patient;
        this.physician = physician;
        this.appointmentDateTime = appointmentDateTime;
        this.reasonForVisit = reasonForVisit;
    }

}