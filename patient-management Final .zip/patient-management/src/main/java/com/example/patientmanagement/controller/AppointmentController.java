package com.example.patientmanagement.controller;

import com.example.patientmanagement.entity.Appointment;
import com.example.patientmanagement.entity.Patient;
import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.service.AppointmentService;
import com.example.patientmanagement.service.EmailService;
import com.example.patientmanagement.service.PatientService;
import com.example.patientmanagement.service.PhysicianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Controller
public class AppointmentController {

    @Autowired
    private EmailService emailService;

    @Autowired
    private PatientService patientService;

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private PhysicianService physicianService;


    @GetMapping("{id}/book-appointment")
    public String showBookingForm(@PathVariable Long id, Model model) {
        // Fetch the patient using the patientId
        Patient patient = patientService.findById(id);

        // Assuming you have methods in your service layer that get specialties and locations
        List<String> specialties = physicianService.getAllSpecialties(); // Get specialties list
        List<String> locations = physicianService.getAllLocations(); // Get locations list
        List<Physician> physicians = new ArrayList<>(); // This will hold the physicians to display

        model.addAttribute("patient", patient); // Add patient to the model
        model.addAttribute("specialties", specialties);
        model.addAttribute("locations", locations);
        model.addAttribute("physicians", physicians);  // Initially, no physicians selected

        return "book-appointment"; // Return the booking form
    }


    @GetMapping("/physicians")
    @ResponseBody
    public List<Physician> getPhysicians(@RequestParam String specialty, @RequestParam String location) {
        // Fetch physicians based on specialty and location
        return physicianService.findBySpecialtyAndLocation(specialty, location);
    }


    @GetMapping("/search-physicians")
    public String searchPhysicians(@RequestParam String specialty, @RequestParam String location, Model model) {
        // Search for physicians based on the specialty and location
        List<Physician> physicians = physicianService.findBySpecialtyAndLocation(specialty, location);

        if (physicians.isEmpty()) {
            model.addAttribute("error", "No physicians found for the selected specialty and location.");
        } else {
            model.addAttribute("physicians", physicians);
        }

        model.addAttribute("specialties", physicianService.getAllSpecialties());
        model.addAttribute("locations", physicianService.getAllLocations());
        return "book-appointment"; // Return to the booking form with search results
    }



    @PostMapping("/book-appointment")
    public String bookAppointment(
            @RequestParam Long patientId,
            @RequestParam String specialty,
            @RequestParam String location,
            @RequestParam String appointmentDateTime,
            @RequestParam int duration, // New duration parameter
            @RequestParam String reasonForVisit,
            @RequestParam Long physicianId,
            Model model) {

        LocalDateTime appointmentDateTimeParsed = LocalDateTime.parse(appointmentDateTime);

        Patient patient = patientService.findById(patientId);

        List<Physician> physicians = physicianService.findBySpecialtyAndLocation(specialty, location);
        Physician physician = physicians.stream()
                .filter(p -> p.getId().equals(physicianId))
                .findFirst()
                .orElse(null);

        if (physician == null) {
            model.addAttribute("error", "Selected physician not found.");
            return "book-appointment";
        }

        boolean isAvailable = appointmentService.isPhysicianAvailable(physician.getId(), appointmentDateTimeParsed, duration);

        if (!isAvailable) {
            model.addAttribute("error", "The physician is not available at the selected time. Please choose another time.");
            return "book-appointment";
        }

        Appointment appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setPhysician(physician);
        appointment.setAppointmentDateTime(appointmentDateTimeParsed);
        appointment.setDuration(duration); // Set duration
        appointment.setReasonForVisit(reasonForVisit);

        // Save and confirm the appointment
        appointmentService.bookAppointment(appointment);
        appointmentService.confirmAppointment(appointment.getId());  // Confirm the appointment

        return "redirect:/dashboard";
    }

}
