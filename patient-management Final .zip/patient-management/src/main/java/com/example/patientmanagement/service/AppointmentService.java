package com.example.patientmanagement.service;

import com.example.patientmanagement.controller.MedicalHistoryController;
import com.example.patientmanagement.entity.Appointment;
import com.example.patientmanagement.repository.AppointmentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AppointmentService {

    private static final Logger log = LoggerFactory.getLogger(AppointmentService.class);
    @Autowired
    private EmailService emailService;
    @Autowired
    private AppointmentRepository appointmentRepository;

    public boolean isPhysicianAvailable(Long physicianId, LocalDateTime requestedStartTime, int duration) {
        LocalDateTime requestedEndTime = requestedStartTime.plusMinutes(duration);

        List<Appointment> appointments = appointmentRepository.findAllByPhysicianId(physicianId);
        for (Appointment appointment : appointments) {
            LocalDateTime existingStartTime = appointment.getAppointmentDateTime();
            LocalDateTime existingEndTime = existingStartTime.plusMinutes(appointment.getDuration());

            // Check for overlap
            if ((requestedStartTime.isBefore(existingEndTime) && requestedStartTime.isAfter(existingStartTime)) ||
                    (requestedEndTime.isAfter(existingStartTime) && requestedEndTime.isBefore(existingEndTime)) ||
                    (requestedStartTime.isEqual(existingStartTime) || requestedEndTime.isEqual(existingEndTime))) {
                return false; // Overlap found, physician not available
            }
        }
        return true; // No overlap, physician is available
    }

    public void bookAppointment(Appointment appointment) {
        // Set to unconfirmed initially
        appointment.setConfirmed(false);
        appointmentRepository.save(appointment);

        // Send confirmation email
        String appointmentDetails = "Appointment with Dr. " + appointment.getPhysician().getFullName() +
                " on " + appointment.getAppointmentDateTime() +
                " for " + appointment.getDuration() + " minutes.";
        emailService.sendConfirmationEmail(appointment.getPatient().getEmail(), appointmentDetails);
        emailService.sendConfirmationEmail(appointment.getPhysician().getEmail(), appointmentDetails);
    }


    public Appointment findAppointmentById(Long id) {
        return appointmentRepository.findById(id).orElse(null);
    }

    public void confirmAppointment(Long id) {
        Appointment appointment = findAppointmentById(id);
        if (appointment != null && !appointment.isConfirmed()) {
            appointment.setConfirmed(true);
            appointmentRepository.save(appointment);
        }
    }

    public boolean hasAppointmentWithPatient(Long physicianId, Long patientId) {
        return appointmentRepository.existsByPhysicianIdAndPatientIdAndIsConfirmed(physicianId, patientId, true);
    }



    public Long getPhysicianIdByPatientId(Long patientId) {
        Appointment appointment = appointmentRepository.findByPatientId(patientId);
        return appointment != null ? appointment.getPhysician().getId() : null;
    }

    public List<Appointment> findAppointmentsByPhysicianId(Long physicianId) {
        return appointmentRepository.findByPhysicianId(physicianId);
    }

}
