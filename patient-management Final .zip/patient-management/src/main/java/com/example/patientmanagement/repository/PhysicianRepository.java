package com.example.patientmanagement.repository;

import com.example.patientmanagement.entity.Physician;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface PhysicianRepository extends JpaRepository<Physician, Long> {
    @Query("SELECT DISTINCT p.specialty FROM Physician p")
    List<String> findDistinctSpecialties();
    List<Physician> findBySpecialtyAndLocation(String specialty, String location);

    Optional<Physician> findByEmail(String username);
}