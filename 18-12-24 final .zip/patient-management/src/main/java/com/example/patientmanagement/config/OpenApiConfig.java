package com.example.patientmanagement.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class OpenApiConfig {

    @Bean
    public GroupedOpenApi publicApi() {
        return GroupedOpenApi.builder()
                .group("public")
                .pathsToMatch(
                        "/register",
                        "/login",
                        "/password-recovery",
                        "/reset-password",
                        "/logout-page",
                        "/confirm-appointment",
                        "/v3/api-docs/**",
                        "/swagger-ui/**",
                        "/swagger-ui.html",
                        "/add-medical-record",
                        "/physician/dashboard",
                        "/dashboard"
                )
                .build();
    }
}


