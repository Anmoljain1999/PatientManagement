package com.example.patientmanagement.service;

import com.example.patientmanagement.entity.Patient;
import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.entity.VerificationToken;
import com.example.patientmanagement.exception.InvalidTokenException;
import com.example.patientmanagement.exception.ResourceNotFoundException;
import com.example.patientmanagement.repository.PatientRepository;
import com.example.patientmanagement.repository.PhysicianRepository;
import com.example.patientmanagement.repository.VerificationTokenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private EmailService emailService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private VerificationTokenRepository tokenRepository;

    @Autowired
    private PhysicianRepository physicianRepository;
    public void registerPatient(Patient patient) {
        patient.setPassword(passwordEncoder.encode(patient.getPassword()));
        patient.setActive(false); // Set to false until email verification
        patient.setRoles(Set.of("ROLE_PATIENT")); // Assign default role
        patientRepository.save(patient);

        VerificationToken verificationToken = createVerificationToken(patient, 24); // 24-hour validity
        tokenRepository.save(verificationToken);

        emailService.sendVerificationEmail(patient.getEmail(), verificationToken.getToken());
    }


    public void sendPasswordResetEmail(String email) {
        // First, check if the email belongs to a Patient
        Patient patient = patientRepository.findByEmail(email).orElse(null);
        if (patient != null) {
            VerificationToken resetToken = createVerificationToken(patient, 1); // 1-hour validity
            tokenRepository.save(resetToken);
            emailService.sendPasswordResetEmail(email, resetToken.getToken());
            return;
        }

        // If not a Patient, check if it belongs to a Physician
        Physician physician = physicianRepository.findByEmail(email).orElse(null);
        if (physician != null) {
            VerificationToken resetToken = createVerificationToken(physician, 1); // 1-hour validity
            tokenRepository.save(resetToken);
            emailService.sendPasswordResetEmail(email, resetToken.getToken());
            return;
        }

        // If no account is found, throw an exception
        throw new ResourceNotFoundException("No account found with that email address.");
    }



    public void resetPassword(String token, String newPassword) {
        // Find the reset token from the repository (throw exception if not found)
        VerificationToken resetToken = tokenRepository.findByToken(token)
                .orElseThrow(() -> new RuntimeException("Invalid password reset token"));

        // Check if the token has expired
        if (resetToken.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token has expired");
        }

        // Determine whether the token belongs to a Patient or Physician
        if (resetToken.getPatient() != null) {
            Patient patient = resetToken.getPatient();
            patient.setPassword(passwordEncoder.encode(newPassword)); // Hash the new password
            patientRepository.save(patient);
        } else if (resetToken.getPhysician() != null) {
            Physician physician = resetToken.getPhysician();
            physician.setPassword(passwordEncoder.encode(newPassword)); // Hash the new password
            physicianRepository.save(physician);
        } else {
            throw new RuntimeException("Token is not associated with any user.");
        }

        // Invalidate the token after use by deleting it
        tokenRepository.delete(resetToken);
    }


    public Patient findByEmail(String email) {
        return patientRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("No patient found with email: " + email));
    }


    public void verifyEmail(String token) {
        VerificationToken verificationToken = tokenRepository.findByToken(token)
                .orElseThrow(() -> new InvalidTokenException("Invalid verification token"));

        if (verificationToken.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new InvalidTokenException("Token has expired");
        }

        Patient patient = verificationToken.getPatient();
        patient.setActive(true);
        patientRepository.save(patient);

        verificationToken.setConfirmedAt(LocalDateTime.now());
        tokenRepository.save(verificationToken);
    }

    private VerificationToken createVerificationToken(Object user, long hoursValid) {
        VerificationToken token = new VerificationToken();
        token.setToken(UUID.randomUUID().toString());
        token.setCreatedAt(LocalDateTime.now());
        token.setExpiresAt(LocalDateTime.now().plusHours(hoursValid));

        if (user instanceof Patient) {
            token.setPatient((Patient) user);
        } else if (user instanceof Physician) {
            token.setPhysician((Physician) user);
        } else {
            throw new IllegalArgumentException("User must be either a Patient or a Physician");
        }

        return token;
    }



    public void updateDemographics(Long id, Patient updatedPatient) {
        Patient existingPatient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));

        existingPatient.setPhoneNumber(updatedPatient.getPhoneNumber());
        existingPatient.setAddress(updatedPatient.getAddress());
        existingPatient.setKnownAllergies(updatedPatient.getKnownAllergies());
        existingPatient.setOngoingConditions(updatedPatient.getOngoingConditions());
        existingPatient.setEmergencyContactName(updatedPatient.getEmergencyContactName());
        existingPatient.setEmergencyContactRelationship(updatedPatient.getEmergencyContactRelationship());
        existingPatient.setEmergencyContactPhone(updatedPatient.getEmergencyContactPhone());
        existingPatient.setInsuranceProvider(updatedPatient.getInsuranceProvider());
        existingPatient.setPolicyNumber(updatedPatient.getPolicyNumber());
        existingPatient.setPolicyExpirationDate(updatedPatient.getPolicyExpirationDate());
        patientRepository.save(existingPatient);
    }

    public Patient findById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));
    }
}
