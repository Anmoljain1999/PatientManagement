package com.example.patientmanagement.service;

import com.example.patientmanagement.entity.Patient;
import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.exception.ResourceNotFoundException;
import com.example.patientmanagement.repository.PatientRepository;
import com.example.patientmanagement.repository.PhysicianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private PhysicianRepository physicianRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Try loading the user as a patient
        Patient patient = patientRepository.findByEmail(username).orElse(null);
        if (patient != null) {
            return new org.springframework.security.core.userdetails.User(
                    patient.getEmail(),
                    patient.getPassword(),
                    getAuthorities(patient)
            );
        }

        // Try loading the user as a physician if not found as a patient
        Physician physician = physicianRepository.findByEmail(username).orElse(null);
        if (physician != null) {
            return new org.springframework.security.core.userdetails.User(
                    physician.getEmail(),
                    physician.getPassword(),
                    getAuthorities(physician)
            );
        }

        // If neither patient nor physician is found, throw an exception
        throw new UsernameNotFoundException("User not found with email: " + username);
    }

    private Collection<? extends GrantedAuthority> getAuthorities(Patient patient) {
        return Collections.singletonList(new SimpleGrantedAuthority("ROLE_PATIENT"));
    }

    private Collection<? extends GrantedAuthority> getAuthorities(Physician physician) {
        Set<GrantedAuthority> authorities = new HashSet<>();
        for (String role : physician.getRoles()) {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + role));
        }
        return authorities;
    }
}



