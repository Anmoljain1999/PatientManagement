package com.example.patientmanagement.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.Set;


@Entity
@Data
public class Physician {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private String fullName;


    private String specialty;

    private String location; // Optional
    private double consultationFee; // Optional

    @Email
    @NotNull
    private String email; // For sending confirmation emails

    @ElementCollection(fetch = FetchType.EAGER)
    private Set<String> roles;

    private String password;

    // Getters and Setters
}