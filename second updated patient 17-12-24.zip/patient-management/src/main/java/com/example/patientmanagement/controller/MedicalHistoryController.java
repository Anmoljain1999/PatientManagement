package com.example.patientmanagement.controller;

import com.example.patientmanagement.entity.MedicalRecord;
import com.example.patientmanagement.entity.Patient;
import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.repository.PatientRepository;
import com.example.patientmanagement.service.AppointmentService;
import com.example.patientmanagement.service.MedicalRecordService;
import com.example.patientmanagement.service.PhysicianService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@Controller
public class MedicalHistoryController {

    private static final Logger log = LoggerFactory.getLogger(MedicalHistoryController.class);
    @Autowired
    private MedicalRecordService medicalRecordService;
    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private PhysicianService physicianService;


//    @GetMapping("/add-medical-record")
//    public String showAddMedicalRecordForm(Model model, @RequestParam Long patientId) {
//        // Retrieve the logged-in physician's email
//        String email = SecurityContextHolder.getContext().getAuthentication().getName();
//
//        // Fetch the physician by email
//        Physician physician = physicianService.findByEmail(email)
//                .orElseThrow(() -> new RuntimeException("Physician not found"));
//
//        // Validate if the physician is authorized to add a medical record for the patient
//        if (!appointmentService.hasAppointmentWithPatient(physician.getId(), patientId)) {
//            throw new RuntimeException("Physician is not authorized to add a medical record for this patient.");
//        }
//
//        // Fetch the patient and create a new MedicalRecord
//        Patient patient = patientRepository.findById(patientId)
//                .orElseThrow(() -> new RuntimeException("Patient not found"));
//        MedicalRecord medicalRecord = new MedicalRecord();
//        medicalRecord.setPatient(patient);
//
//        // Add to the model
//        model.addAttribute("medicalRecord", medicalRecord);
//        return "add-medical-record"; // Render the form
//    }


    @GetMapping("/add-medical-record")
    public String showAddMedicalRecordForm(Model model, @RequestParam Long patientId) {
        // Retrieve the logged-in physician's email
        String email = SecurityContextHolder.getContext().getAuthentication().getName();

        log.info("Logged-in user email: {}", email);

        // Fetch the physician by email
        Physician physician = physicianService.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Physician not found"));

        log.info("Physician ID: {}, Patient ID: {}", physician.getId(), patientId);

        // Validate if the physician is authorized to add a medical record for the patient (only for confirmed appointments)
        boolean hasConfirmedAppointment = appointmentService.hasAppointmentWithPatient(physician.getId(), patientId);

        log.info("Authorization check result (confirmed appointment): {}", hasConfirmedAppointment);

        if (!hasConfirmedAppointment) {
            throw new RuntimeException("Physician is not authorized to add a medical record for this patient.");
        }

        // Fetch the patient and create a new MedicalRecord
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found"));

        MedicalRecord medicalRecord = new MedicalRecord();
        medicalRecord.setPatient(patient);

        // Add to the model
        model.addAttribute("medicalRecord", medicalRecord);
        return "add-medical-record";
    }







//    @PostMapping("/add-medical-record")
//    public String addMedicalRecord(MedicalRecord medicalRecord) {
//        medicalRecordService.saveMedicalRecord(medicalRecord);
//        return "redirect:/dashboard"; // Redirect to dashboard after saving
//    }


//    @PostMapping("/add-medical-record")
//    public String addMedicalRecord(@RequestParam Long patientId, Model model) {
//        // Retrieve the Patient by ID from the request
//        Patient patient = patientRepository.findById(patientId)
//                .orElseThrow(() -> new RuntimeException("Patient not found"));
//
//        // Retrieve the Physician by the logged-in user's email
//        String physicianEmail = SecurityContextHolder.getContext().getAuthentication().getName();
//        Physician physician = physicianService.findByEmail(physicianEmail)
//                .orElseThrow(() -> new RuntimeException("Physician not found"));
//
//        // Create a new MedicalRecord object and set the patient and physician
//        MedicalRecord medicalRecord = new MedicalRecord();
//        medicalRecord.setPatient(patient);
//        medicalRecord.setPhysician(physician);
//
//        // Add the medical record to the model for the form to be populated
//        model.addAttribute("medicalRecord", medicalRecord);
//
//        return "add-medical-record";  // Return the view for adding a medical record
//    }

    @PostMapping("/add-medical-record")
    public String addMedicalRecord(@ModelAttribute("medicalRecord") MedicalRecord medicalRecord, Model model) {
      
        medicalRecordService.saveMedicalRecord(medicalRecord);

        // Add a success message to the model to display on the success page
        model.addAttribute("successMessage", "Medical record added successfully!");

        // Return the same view that allows them to navigate back to the dashboard
        return "add-medical-record-success";  // The success page template name
    }




    @GetMapping("/{id}/medical-history")
    public String viewMedicalHistory(Model model,@PathVariable("id") Long patientId) {
        List<MedicalRecord> medicalHistory = medicalRecordService.getMedicalHistory(patientId);
        model.addAttribute("medicalHistory", medicalHistory);
        return "medical-history"; // A view to display medical history
    }
}