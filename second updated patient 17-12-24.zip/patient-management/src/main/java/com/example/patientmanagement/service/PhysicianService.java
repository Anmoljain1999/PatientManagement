package com.example.patientmanagement.service;

import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.exception.ResourceNotFoundException;
import com.example.patientmanagement.repository.PhysicianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PhysicianService {

    @Autowired
    private PhysicianRepository physicianRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<Physician> findAll() {
        return physicianRepository.findAll();
    }

    public void savePhysician(Physician physician) {
        physicianRepository.save(physician);
    }

    public Physician findById(Long physicianId) {
        return physicianRepository.findById(physicianId)
                .orElseThrow(() -> new ResourceNotFoundException("Physician with ID " + physicianId + " not found."));
    }

    public List<String> getAllSpecialties() {
        return physicianRepository.findDistinctSpecialties();
    }

    public List<Physician> findBySpecialtyAndLocation(String specialty, String location) {
        return physicianRepository.findBySpecialtyAndLocation(specialty, location);
    }

    public List<String> getAllLocations() {
        List<Physician> physicians = physicianRepository.findAll();
        Set<String> locations = new HashSet<>();

        for (Physician physician : physicians) {
            String location = physician.getLocation();
            if (location != null && !location.isEmpty()) {
                locations.add(location);
            }
        }

        return new ArrayList<>(locations); // Return a list of unique locations
    }

    public void registerPhysician(Physician physician) {
        physician.setRoles(Set.of("PHYSICIAN")); // Default role
        physician.setPassword(passwordEncoder.encode(physician.getPassword()));
        physicianRepository.save(physician);
    }


    public Optional<Physician> findByEmail(String email) {
        return physicianRepository.findByEmail(email);
    }

}