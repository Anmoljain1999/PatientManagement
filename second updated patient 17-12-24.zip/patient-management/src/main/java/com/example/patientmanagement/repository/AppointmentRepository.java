package com.example.patientmanagement.repository;

import com.example.patientmanagement.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    boolean existsByPhysicianIdAndPatientIdAndIsConfirmed(Long physicianId, Long patientId, boolean isConfirmed);

    Appointment findByPatientId(Long patientId);

    List<Appointment> findAllByPhysicianId(Long physicianId);

    List<Appointment> findByPhysicianId(Long physicianId);
}