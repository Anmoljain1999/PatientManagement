package com.example.patientmanagement.controller;

import com.example.patientmanagement.entity.Appointment;
import com.example.patientmanagement.entity.Patient;
import com.example.patientmanagement.entity.Physician;
import com.example.patientmanagement.service.AppointmentService;
import com.example.patientmanagement.service.EmailService;
import com.example.patientmanagement.service.PatientService;
import com.example.patientmanagement.service.PhysicianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Controller
public class AppointmentController {

    @Autowired
    private EmailService emailService;

    @Autowired
    private PatientService patientService;

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private PhysicianService physicianService;


    @GetMapping("{id}/book-appointment")
    public String showBookingForm(
            @PathVariable Long id,
            Model model,
            @RequestParam(value = "specialty", required = false) String specialty,
            @RequestParam(value = "location", required = false) String location,
            @RequestParam(value = "appointmentDateTime", required = false) String appointmentDateTime,
            @RequestParam(value = "reasonForVisit", required = false) String reasonForVisit) {

        // Fetch the patient using the patientId
        Patient patient = patientService.findById(id);

        // Fetch specialties and locations
        List<String> specialties = physicianService.getAllSpecialties();
        List<String> locations = physicianService.getAllLocations();

        // Fetch physicians if specialty and location are provided
        List<Physician> physicians = new ArrayList<>();
        if (specialty != null && location != null) {
            physicians = physicianService.findBySpecialtyAndLocation(specialty, location);
        }

        // Add necessary attributes to the model
        model.addAttribute("patient", patient);
        model.addAttribute("specialties", specialties);
        model.addAttribute("locations", locations);
        model.addAttribute("physicians", physicians);

        // Add form data if provided
        model.addAttribute("selectedSpecialty", specialty);
        model.addAttribute("selectedLocation", location);
        model.addAttribute("appointmentDateTime", appointmentDateTime);
        model.addAttribute("reasonForVisit", reasonForVisit);

        // Add error message if present
        if (!model.containsAttribute("error")) {
            model.addAttribute("error", null);
        }

        return "book-appointment"; // Render the booking form
    }


    @GetMapping("/physicians")
    @ResponseBody
    public List<Physician> getPhysicians(@RequestParam String specialty, @RequestParam String location) {
        // Fetch physicians based on specialty and location
        return physicianService.findBySpecialtyAndLocation(specialty, location);
    }


    @GetMapping("/search-physicians")
    public String searchPhysicians(@RequestParam String specialty, @RequestParam String location, Model model) {
        // Search for physicians based on the specialty and location
        List<Physician> physicians = physicianService.findBySpecialtyAndLocation(specialty, location);

        if (physicians.isEmpty()) {
            model.addAttribute("error", "No physicians found for the selected specialty and location.");
        } else {
            model.addAttribute("physicians", physicians);
        }

        model.addAttribute("specialties", physicianService.getAllSpecialties());
        model.addAttribute("locations", physicianService.getAllLocations());
        return "book-appointment"; // Return to the booking form with search results
    }



    @PostMapping("/book-appointment")
    public String bookAppointment(
            @RequestParam Long patientId,
            @RequestParam String specialty,
            @RequestParam String location,
            @RequestParam String appointmentDateTime,
            @RequestParam int duration,
            @RequestParam String reasonForVisit,
            @RequestParam Long physicianId,
            RedirectAttributes redirectAttributes) {

        LocalDateTime appointmentDateTimeParsed = LocalDateTime.parse(appointmentDateTime);

        Patient patient = patientService.findById(patientId);

        List<Physician> physicians = physicianService.findBySpecialtyAndLocation(specialty, location);
        Physician physician = physicians.stream()
                .filter(p -> p.getId().equals(physicianId))
                .findFirst()
                .orElse(null);

        if (physician == null) {
            redirectAttributes.addFlashAttribute("error", "Selected physician not found.");
            return "redirect:/" + patientId + "/book-appointment";
        }

        boolean isAvailable = appointmentService.isPhysicianAvailable(physician.getId(), appointmentDateTimeParsed, duration);

        if (!isAvailable) {
            redirectAttributes.addFlashAttribute("error", "The physician is not available at the selected time. Please choose another time.");
            redirectAttributes.addFlashAttribute("specialty", specialty);
            redirectAttributes.addFlashAttribute("location", location);
            redirectAttributes.addFlashAttribute("appointmentDateTime", appointmentDateTime);
            redirectAttributes.addFlashAttribute("reasonForVisit", reasonForVisit);
            return "redirect:/" + patientId + "/book-appointment";
        }

        Appointment appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setPhysician(physician);
        appointment.setAppointmentDateTime(appointmentDateTimeParsed);
        appointment.setDuration(duration);
        appointment.setReasonForVisit(reasonForVisit);

        appointmentService.bookAppointment(appointment);
        appointmentService.confirmAppointment(appointment.getId());

        return "redirect:/dashboard";
    }


}
